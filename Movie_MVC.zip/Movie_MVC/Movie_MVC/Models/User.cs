﻿using Microsoft.AspNetCore.Identity;

namespace L8HandsOn.Models
{
    public class User : IdentityUser
    {
    }
}
