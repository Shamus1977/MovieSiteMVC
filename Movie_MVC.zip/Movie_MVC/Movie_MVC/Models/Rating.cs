﻿namespace L8HandsOn.Models
{
    public enum Rating
    {
        Select = 0,
        NotRated,
        G,
        PG,
        PG13,
        R,
        NC17
    }
}
