﻿namespace L8HandsOn.Models
{
    public enum Genre
    {
        Select = 0,
        Romance,
        Thriller,
        Horror,
        Comedy,
        Mystery,
        Drama,
        Action,
        Documentery,
        Biography,
        Western,
        ScienceFiction,
        Children,
        Animation,
        RomanticComedy
    }
}
